// Copyright (c) 2019 . Wilberforce Uwadiegwu. All Rights Reserved.

package com.jadebyte.jadeplayer.main.common.network.image

import java.io.File

interface FileFetcher {
    fun fetchFile(): File
}