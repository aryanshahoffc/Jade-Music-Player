// Copyright (c) 2019 . Wilberforce Uwadiegwu. All Rights Reserved.

package com.jadebyte.jadeplayer.main.playback

import com.jadebyte.jadeplayer.main.common.view.BaseFragment


/**
 * Created by Wilberforce on 2019-08-18 at 19:06.
 */
class BasePlaybackFragment: BaseFragment() {

}